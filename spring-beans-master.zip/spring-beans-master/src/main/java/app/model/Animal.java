package app.model;

public abstract class Animal {
}
